package mk.ukim.finki.lab_2.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.lab_2.model.Category;
import mk.ukim.finki.lab_2.model.Event;
import mk.ukim.finki.lab_2.model.EventBooking;
import mk.ukim.finki.lab_2.model.Location;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


@Component
public class DataHolder {
    public static final List<Event> events = new ArrayList<>(10);
    public static final List<EventBooking> MyBookings = new ArrayList<>();
    public static final List<Category> categories = new ArrayList<>();
    public static final List<Location> locations = new ArrayList<>();

    public DataHolder() {

        categories.add(new Category(1L, "Category 1"));
        categories.add(new Category(2L, "Category 2"));
        categories.add(new Category(3L, "Category 3"));
        categories.add(new Category(4L, "Category 4"));
        categories.add(new Category(5L, "Category 5"));
        categories.add(new Category(6L, "Category 6"));

        locations.add(new Location("Location 1", 1L));
        locations.add(new Location("Location 2", 2L));
        locations.add(new Location("Location 3", 3L));
        locations.add(new Location("Location 4", 4L));
        locations.add(new Location("Location 5", 5L));
        locations.add(new Location("Location 6", 6L));
        locations.add(new Location("Location 7", 7L));
        locations.add(new Location("Location 8", 8L));
        locations.add(new Location("Location 9", 9L));
        locations.add(new Location("Location 10", 10L));
        
       

        events.add(new Event(1L, "Event 1", "Desc 1", 9, categories.get(2), locations.get(0)));
        events.add(new Event(2L, "Event 2", "Desc 2", 10, categories.get(2), locations.get(1)));
        events.add(new Event(3L, "Event 3", "Desc 3", 8, categories.get(0), locations.get(2)));
        events.add(new Event(4L, "Event 4", "Desc 4", 10, categories.get(0), locations.get(3)));
        events.add(new Event(5L, "Event 5", "Desc 5", 7, categories.get(0), locations.get(4)));
        events.add(new Event(6L, "Event 6", "Desc 6", 10, categories.get(3), locations.get(5)));
        events.add(new Event(7L, "Event 7", "Desc 7", 9, categories.get(0), locations.get(6)));
        events.add(new Event(8L, "Event 8", "Desc 8", 7, categories.get(1), locations.get(7)));
        events.add(new Event(9L, "Event 9", "Desc 9", 8, categories.get(4), locations.get(8)));
        events.add(new Event(10L, "Event 10", "Desc 10", 6, categories.get(5), locations.get(9)));
    }
}